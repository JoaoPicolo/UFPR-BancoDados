select
    distinct(o_orderstatus)
from
    ORDERS;