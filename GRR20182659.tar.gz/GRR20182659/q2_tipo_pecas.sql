select
    distinct(p_type)
from
    PART;